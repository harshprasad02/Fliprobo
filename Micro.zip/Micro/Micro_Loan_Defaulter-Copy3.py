#!/usr/bin/env python
# coding: utf-8

# # Micro-Credit Defaulter Model

# ### Description
# 
# Microfinance is defined as any activity that includes the provision of financial services such as credit, savings, and insurance to low income individuals which fall just above the nationally defined poverty line, and poor individuals which fall below that poverty line, with the goal of creating social value. The creation of social value includes poverty alleviation and the broader impact of improving livelihood opportunities through the provision of capital for micro enterprise, and insurance and savings for risk mitigation and consumption smoothing. Predicting the status of a loan is also an important problem in risk assessment. A Institution like Micro finance institutions which provides loans to the poor people especially those who do not have any bank accounts. These institutions have granted approximately 70 thousand billion dollars, which is still outstanding till date. Therefore, this institution has to be able to estimate the risk involved before granting a loan to a customer. With the help of this we are predicting whether the customer will be returning the loan in the given time period of 5 days or not.
# 
The datas set includes following features:


label           	   Flag indicating whether the user paid back the credit amount within 5 days of issuing the loan{1:success, 0:failure}	

msisdn                 mobile number of user	

aon	                   age on cellular network in days	

daily_decr30    	   Daily amount spent from main account, averaged over last 30 days (in Indonesian Rupiah)	

daily_decr31    	   Daily amount spent from main account, averaged over last 90 days (in Indonesian Rupiah)	

rental30         	   Average main account balance over last 30 days	Unsure of given definition

rental90	           Average main account balance over last 90 days	Unsure of given definition

last_rech_date_ma	   Number of days till last recharge of main account	

last_rech_date_da	   Number of days till last recharge of data account	

last_rech_amt_ma	   Amount of last recharge of main account (in Indonesian Rupiah)	

cnt_ma_rech30	       Number of times main account got recharged in last 30 days	

fr_ma_rech30	        Frequency of main account recharged in last 30 days	Unsure of given definition

sumamnt_ma_rech30	    Total amount of recharge in main account over last 30 days (in Indonesian Rupiah)	

medianamnt_ma_rech30	 Median of amount of recharges done in main account over last 30 days at user level (in Indonesian Rupiah)	

medianmarechprebal30	 Median of main account balance just before recharge in last 30 days at user level (in Indonesian Rupiah)	
cnt_ma_rech90	         Number of times main account got recharged in last 90 days	

fr_ma_rech90	         Frequency of main account recharged in last 90 days	Unsure of given definition

sumamnt_ma_rech90	     Total amount of recharge in main account over last 90 days (in Indonasian Rupiah)	

medianamnt_ma_rech90	  Median of amount of recharges done in main account over last 90 days at user level (in Indonasian Rupiah)	

medianmarechprebal90	  Median of main account balance just before recharge in last 90 days at user level (in Indonasian Rupiah)	

cnt_da_rech30	          Number of times data account got recharged in last 30 days	

fr_da_rech30	          Frequency of data account recharged in last 30 days	

cnt_da_rech90	          Number of times data account got recharged in last 90 days	

fr_da_rech90	          Frequency of data account recharged in last 90 days	

cnt_loans30	              Number of loans taken by user in last 30 days	

amnt_loans30	          Total amount of loans taken by user in last 30 days	

maxamnt_loans30	          maximum amount of loan taken by the user in last 30 days	There are only two options: 5 & 10 Rs., for which the user needs to pay back 6 & 12 Rs. respectively.

medianamnt_loans30	  Median of amounts of loan taken by the user in last 30 days	

cnt_loans90        	  Number of loans taken by user in last 90 days	

amnt_loans90	      Total amount of loans taken by user in last 90 days	

maxamnt_loans90	      maximum amount of loan taken by the user in last 90 days	

medianamnt_loans90	  Median of amounts of loan taken by the user in last 90 days	

payback30	          Average payback time in days over last 30 days	

payback90	          Average payback time in days over last 90 days	

pcircle	              telecom circle	

pdate	               date	

# Our target variable is "label" which is a categorical variable so we'll importing libraries for the same.

# In[8]:


import numpy as np
import pandas as pd
import sklearn
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')


# In[9]:


Mcd = pd.read_csv("E:\Flip_Robo\Micro Credit Project\Data file.csv",index_col = 0)


# In[10]:


Mcd


# In[11]:


Mcd.shape


# The Data file has 209593 rows and 36 columns including the target column.

# In[12]:


Mcd.info()


# In[13]:


pd.set_option('display.max_rows', None)


# In[14]:


#checking data types of each column

Mcd.dtypes


# In[15]:


# cheking null values present in data set

Mcd.isnull().sum()


# In[16]:


plt.figure(figsize = [16,6])
sns.heatmap(Mcd.isnull())
plt.title('Null values')
plt.show()


# So from the above outputs we can confirms that there is no missing values in the dataset

# In[17]:


# Statistical summary of the data set
pd.set_option('display.max_columns',None)

Mcd.describe()


# The statistical summary is obtained for 33 columns.The columns 'msisdn' contains unrealistic phone numbers, 'pcircle' contains region of telecom circle and 'pdate' has dates.So, we can drop these columns for statistical analysis.

# As we can see that difference between the 75 percentile and maximum value is very high in most of the columns.
# Minimum value of most of the variables are given is in negative or zero.Standard deviation of all the feature is very high it means that outliers are present.There is a huge difference between the mean and 50 percentile data i.e. mean is greater than the 50th percentile(median) in most of the features,excluding cnt_ma_rech30,cnt_ma_rech90,fr_ma_rech90,medianmarechprebal90,cnt_da_rech90,fr_da_rech90,cnt_loans30,amnt_loans30,amnt_loans90,
# maxamnt_loans90,medianamnt_loans90 ,payback30 and payback90.The large difference between mean and median indicates that the features are skewed.

# ### Univariant analysis

# In[18]:


Mcd['label'].hist(grid = True)


# In[19]:


sns.countplot(Mcd['label'])


# Observation : We can confirmed that there is high data imbalance present in 'label' column. So we will remove it.

# In[20]:


#univariant analysis of other variables


# In[21]:


x1 = Mcd.drop(['msisdn','pcircle','pdate','label'], axis = 1)


# In[22]:


for i in x1:
    plt.figure(figsize=[6,6])
    sns.distplot(x1[i])

Observation:
as we can see that skewness is present in most of the variables of the data set.
1.Variables which are right skewed:
a.daily_decr30.
b.daily_decr90
c.rental90           (shows sharp peak from 0 to less than 50000 on x axis) 
d.cnt_ma_rech30      (shows sharp peak from 0 to less than 50 on x axis ranging from 0 to 0.16)
e.sumamnt_ma_rech30,
f.cnt_ma_rech90      (shows sharp peak from 0 to less than 50 on x axis)
g.fr_ma_rech90       (shows sharp peak from 0 to less than 20 on x axis and ranges from .00 to 0.25 on y axis)
h.payback30
i.payback90
Also,last_rect_amt_ma,cnt_loans30,amnt_loans30,amnt_loans90 is a bit right skewed but can't be determind properly.
can't be determined for other variables.
# In[23]:


#Multivariant analysis


# In[24]:


sns.pairplot(Mcd)


# observations: since Number of columns are high the graphs are very small and not much insights can be obtained from the it. But still we can see that few columns are correalted to each other to confirm that will do few more tests.

# In[26]:


#plotting the graphs against 'label' 
for i in x1:
    x = x1[i]
    y = Mcd['label']
    plt.xlabel(i)
    plt.ylabel('label')
    sns.scatterplot(x,y,hue = Mcd['label'])
    plt.show() 


# Observation:
# 1. Daily amount spent from main account is from 0 to 50,000 both possibilities are there,i.e,can be a defaulter or not. after that there is no defaulter.(averaged over last 30 days and 90 days) 
# 2. When Average main account balance remains from 0 to 50,000 both possibiities are there ,i.e,can be a defaulter or not.the persons having balance more that 50000 are non defaulter.(over 30days nad 90 days)
# 3. when the Number of times main account got rechared is between 0 to less than 50 both possibilities are there,i.e,can be a defaulter or not.after that people has returned the loan amount.(whn recharge is done in 30 days or 90).
# 4. when Total amount of recharge in main account is more than 100000 there are no defaulters but when it is below that both possibilities are there,i.e,can be a defaulter or not.(over 30 days)
# 5. when Total amount of recharge in main account is more than 200000 then there are no defaulters but when it is below that both possibilities are there,i.e,can be a defaulter or not.(over 90 days)
# 6. when Number of times data account got recharged is between 20 to 30 there are no defaulters.(in last 90 days)
# 7. when Frequency of data account recharged is more than 35 there are no defaulters but when it is below that both possibilities are there,i.e,can be a defaulter or not.(over 90 days).
# 8. when Number of loans taken by user in last 30 days is more 20 there are no defaulters but below that both possibilities are there,i.e,can be a defaulter or not.
# 9. when Total amount of loans taken by user in last 30 days is more than 120 there are no defaulters but below that both possibilities are there,i.e,can be a defaulter or not.
# 10. when Median of amounts of loan taken by the user in last 90 days is more than 1 no defaulters are present but below that both possibilities are there,i.e,can be a defaulter or not.
# 11. when Total amount of loans taken by user in last 90 days is more than 150 there are no defaulters but below that both possibilities are there,i.e,can be a defaulter or not.

# In[28]:


#checkng outliers in the dataset 
#plotting boxplot fot first few columns to check outliers


# In[29]:


Mcd.iloc[:,2:7].boxplot()


# Too many outliers are present in all the columns.

# In[30]:


Mcd.iloc[:,8:13].boxplot(figsize = [10,4])


# Too many outliers are present in all the columns.but not sure cnt_ma_rech30 so will plot separately.

# In[31]:


Mcd.boxplot(column = 'cnt_ma_rech30')


# Here we can seee too many outliers present.

# In[32]:


Mcd.iloc[:,14:18].boxplot(figsize = [10,4])


# Too many outliers are present in all the columns

# In[33]:


Mcd.iloc[:,18:22].boxplot(figsize = [10,6])


# Too many outliers are present in all the columns.in fr_da_rech30 outliers are present very far from the whiskers

# In[34]:


Mcd.iloc[:,22:26].boxplot(figsize = [10,6])


# Too many outliers are present in all the columns.

# In[35]:


Mcd.iloc[:,26:30].boxplot(figsize = [10,6])


# Too many outliers present in maxamnt_loans30. Plotting other features to check outliers

# In[36]:


Mcd.boxplot(column = 'medianamnt_loans30',figsize = [10,6])


# outliers are present but very small.

# In[37]:


Mcd.iloc[:,28:30].boxplot(figsize = [10,6])


# too many outliers are present in the features.

# In[38]:


Mcd.iloc[:,32:35].boxplot(figsize = [10,6])


# Too many outliers are present in Payback30 and payback90

# We will be removing outliers from the features in further steps.

# In[39]:


#removing outliers.


# In[40]:


Mcd1 = Mcd.drop(["msisdn", "pcircle","pdate"],axis = 1)


# In[41]:


#removing outlier
from scipy.stats import zscore
z = np.abs(zscore(Mcd1))


# In[42]:


threshold = 3
print(np.where(z>3))


# In[43]:


df_new = Mcd1[(z<3).all(axis = 1)]


# In[44]:


df_new.shape


# In[45]:


Mcd1.shape


# In[46]:


data_lose = ((209593 - 161465)/209593)*100


# In[47]:


print(data_lose)


# 22.96% data is lost after removing the outliers using z score method.

# In[48]:


df_new.columns


# In[115]:


df_new.describe()


# In[ ]:


aon


# In[49]:


#cheking for the skewness and removing skewness.


# In[50]:


x = df_new.drop("label", axis = 1)
y = df_new["label"]            


# In[51]:


x.shape


# In[52]:


y.shape


# In[53]:


df_new.skew()


# Skewness is present in all features except fr_da_rech90 .All of them are right skewed.Some of the features like ,last_rech_date_da,medianmarechprebal30,cnt_da_rech30,maxamnt_loans30 are highly skewed.We will be removing them.

# In[54]:


#removing skewness


# In[55]:


from sklearn.preprocessing import power_transform
df1 = power_transform(x)  


# In[56]:


df1 = pd.DataFrame(df1,columns= x.columns)


# In[57]:


df1.skew()


# Skewness has been removed from most of the features.

# In[58]:


#cheking features which we can use for model selection


# In[59]:


corr_matrix = Mcd.corr()


# In[60]:


#plotting heat map
plt.figure(figsize = [16,10])
sns.heatmap(corr_matrix, annot = True)
plt.show()


# observation : The values are not visible and are difficult to read so we  will sort the values with respect to our label variable,to check their relationship with it

# Not much insights can be made from the above.

# In[27]:


#checking co relation with the class variable


# In[62]:


corr=corr_matrix['label'].sort_values(ascending = False)
corr = pd.DataFrame(corr)
corr


# Observations:
# 
# Highly correlated features with target class "label": cnt_ma_rech30,cnt_ma_rech90,sumamnt_ma_rech90,sumamnt_ma_rech30,amnt_loans90,amnt_loans30,cnt_loans30.
# 
# Lowest related features with target class 'label": cnt_loans90,cnt_da_rech30,last_rech_date_ma,cnt_da_rech90,
# last_rech_date_da,fr_ma_rech3,maxamnt_loans30,fr_da_rech30,aon,medianmarechprebal30,fr_da_rech90

# Lets drop those features which are least correlated to the target variables.

# In[63]:


x = df1.drop(["maxamnt_loans30","fr_da_rech30"],axis = 1)


# In[64]:


x.shape


# In[65]:


y.shape


# In[66]:


y.value_counts()


# In[ ]:


Maxaccu = 0
Maxrow = 0
for i in range(1,200):
    x_train,x_test,y_train,y_test = train_test_split(x,y,test_size = .20,random_state = i)
    lr = LogisticRegression()
    lr.fit(x_train,y_train)
    prdlr = lr.predict(x_test)
    accu = accuracy_score(y_test,prdlr)
    if accu>Maxaccu:
        Maxaccu = accu
        Maxrow = i
print("max accuracy is : ",Maxaccu ,"at random state : ",Maxrow)


# using 143 as random state for the model building

# In[68]:


x_train,x_test,y_train,y_test = train_test_split(x,y,test_size = .20,random_state = 143)


# In[69]:


from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()
lr.fit(x_train,y_train)
prdlr = lr.predict(x_test)
print(accuracy_score(y_test,prdlr))
print(confusion_matrix(y_test,prdlr))
print(classification_report(y_test,prdlr))

Model obserervation:
    precision : for 0 its 0.62 
                for 1 its 0.89
                precision value of 0 is very low compared to 1 which means model is not efficient for the value 0
    recall : the 
        
        
    f1 score as we can see that due to imbalance data set the model is biased for the non defaulters. 
# In[70]:


#using undersample ato remove data imbalance


# In[71]:


from imblearn.under_sampling import NearMiss
from collections import Counter


# In[80]:


ns = NearMiss()


# In[93]:


x_ns,y_ns = ns.fit_resample(x,y)


# In[94]:


print("The Number of classes before fit {} ".format(Counter(y)))
print("The Number of classes After fit {} ".format(Counter(y_ns)))


# using it to predict model accuracy

# In[95]:


x_train,x_test,y_train,y_test = train_test_split(x_ns,y_ns,test_size = .20,random_state = 143)


# In[101]:


lr = LogisticRegression()
lr.fit(x_train,y_train)
prdlr = lr.predict(x_test)
print("logistic regression")
print(accuracy_score(y_test,prdlr))
print(confusion_matrix(y_test,prdlr))
print(classification_report(y_test,prdlr))


# In[ ]:


#using oversampling


# In[97]:


from imblearn.over_sampling import RandomOverSampler


# In[108]:


os = RandomOverSampler()

x_ns,y_ns = os.fit_resample(x,y)
print("The Number of classes before fit {} ".format(Counter(y)))
print("The Number of classes After fit {} ".format(Counter(y_ns)))


# In[105]:


x_train,x_test,y_train,y_test = train_test_split(x_ns,y_ns,test_size = .20,random_state = 143)

lr = LogisticRegression()
lr.fit(x_train,y_train)
prdlr = lr.predict(x_test)
print("logistic regression")
print(accuracy_score(y_test,prdlr))
print(confusion_matrix(y_test,prdlr))
print(classification_report(y_test,prdlr))


# In[104]:


#By using over sampling our model shows more accuracy compared to under sampling


# In[110]:


from imblearn.combine import SMOTETomek


# In[111]:


os = SMOTETomek()

x_ns,y_ns = os.fit_resample(x,y)
print("The Number of classes before fit {} ".format(Counter(y)))
print("The Number of classes After fit {} ".format(Counter(y_ns)))


# In[112]:


x_train,x_test,y_train,y_test = train_test_split(x_ns,y_ns,test_size = .20,random_state = 143)

lr = LogisticRegression()
lr.fit(x_train,y_train)
prdlr = lr.predict(x_test)
print("logistic regression")
print(accuracy_score(y_test,prdlr))
print(confusion_matrix(y_test,prdlr))
print(classification_report(y_test,prdlr))


# .so we can see that by using SMOTETomek we have balanced our data.
# the f1 score of the model is equal for both defaulters and non defaulters.which means both theclasses are well balanced and no biasness is presnet in the model.also the positives or precision of the model is good so we can proceed with it.

# In[113]:


#doing standard scaling of the dataset


# In[114]:


from sklearn.preprocessing import StandardScaler


# In[116]:


scaler = StandardScaler()
x_ns = scaler.fit_transform(x_ns)


# In[118]:


x_train,x_test,y_train,y_test = train_test_split(x_ns,y_ns,test_size = .20,random_state = 143)


# In[119]:


x_train.shape


# In[120]:


x_test.shape


# In[121]:


lr = LogisticRegression()
lr.fit(x_train,y_train)
prdlr = lr.predict(x_test)
print("logistic regression")
print(accuracy_score(y_test,prdlr))
print(confusion_matrix(y_test,prdlr))
print(classification_report(y_test,prdlr))


# In[122]:


from sklearn.tree import DecisionTreeClassifier
dtc = DecisionTreeClassifier()
dtc.fit(x_train,y_train)
prdtc = dtc.predict(x_test)
print(accuracy_score(y_test,prdtc))
print(confusion_matrix(y_test,prdtc))
print(classification_report(y_test,prdtc))


# In[123]:


from sklearn.ensemble import RandomForestClassifier
rfc = RandomForestClassifier()
rfc.fit(x_train,y_train)
prdrfc = rfc.predict(x_test)
print(accuracy_score(y_test,prdrfc))
print(confusion_matrix(y_test,prdrfc))
print(classification_report(y_test,prdrfc))


# In[125]:


from sklearn.svm import SVC
svc = SVC()
svc.fit(x_train,y_train)
prdsvc = svc.predict(x_test)
print(accuracy_score(y_test,prdsvc))
print(confusion_matrix(y_test,prdsvc))
print(classification_report(y_test,prdsvc))


# In[127]:


#checking cross validation of the model


# In[128]:


from sklearn.model_selection import cross_val_score
scr = cross_val_score(lr,x_ns,y_ns,cv = 5)
print("Cross validation score of Logistic Regression is ",scr.mean())


# In[129]:


from sklearn.model_selection import cross_val_score
scr = cross_val_score(dtc,x_ns,y_ns,cv = 5)
print("Cross validation score of Decision Tree Classifier is ",scr.mean())


# In[130]:


from sklearn.model_selection import cross_val_score
scr = cross_val_score(rfc,x_ns,y_ns,cv = 5)
print("Cross validation score of Random Forest Classifier is ",scr.mean())


# In[ ]:


from sklearn.model_selection import cross_val_score
scr = cross_val_score(svc,x_ns,y_ns,cv = 5)
print("Cross validation score of Support vector Classifier is ",scr.mean())


# From the above result when we checked the difference between the predicted accuracy and cross value score ,there is very less difference between each score.So,We can conclude that the RandomForest Classifier shows the hoghest accuracy and we will work on that for model building 

# In[132]:


#randomforest is selected 


# #### Hyperparameter Tuning for random forest classifier

# In[168]:


from sklearn.model_selection import GridSearchCV
#creating parameter list to pass in GridSearchCV
parameters = {'max_depth' : np.arange(2,7),
             'criterion': ['gini','entropy']}                  


# In[169]:


GVC = GridSearchCV(RandomForestClassifier(),parameters,cv = 5)


# In[170]:


GVC.fit(x_train,y_train)


# In[171]:


GVC.best_params_


# In[174]:


Mod = RandomForestClassifier(criterion = 'gini',max_depth = 6,random_state = 143)
Mod.fit(x_train,y_train)
pred = Mod.predict(x_test)
print("accuracy score of the model is :",accuracy_score(y_test,pred)*100)


# In[175]:


print(confusion_matrix(y_test,pred))
print(classification_report(y_test,pred))


# Since the model is showing more accuracy without hyperparameter tuning we will not tune our mode and will use the actual model i.e, rfc.

# In[ ]:




